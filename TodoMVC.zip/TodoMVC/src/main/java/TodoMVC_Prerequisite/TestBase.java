package TodoMVC_Prerequisite;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestBase 

{
	public static WebDriver driver;

	public static void main(String[] args) throws IOException
	
	{
			initialization();
	}
	
	public static void initialization() throws IOException
	{
		Properties prop= new Properties();
		FileInputStream fis=new FileInputStream("D://Only_Selenium//TodoMVC//src//main//java//TodoMVC_Prerequisite//config.properties");
		prop.load(fis);
		String URL=prop.getProperty("url");
		System.setProperty("webdriver.chrome.driver", "D:\\Drivers\\chromedriver_win32\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get(URL);
		
		
		
	}

}
