package TodoMVC_TestCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import TodoMVC_Prerequisite.TestBase;

public class TestCase3_AddTaskto_TodosList extends TestBase
{
	@BeforeMethod
	  public void setup() throws IOException
	  {
		  TestBase.initialization();  
	  }
	
	
	  
	  @Test
	  public void Verify_taskadded()
	  {
		 WebElement inputbox= driver.findElement(By.xpath("//input[@class='new-todo']"));
		 inputbox.sendKeys("Task1");
		 inputbox.sendKeys(Keys.ENTER);
		 inputbox.sendKeys("Task2");
		 inputbox.sendKeys(Keys.ENTER);
		 String str= driver.findElement(By.xpath("//span[@class='todo-count']/strong")).getText();
		 System.out.println("Total number of task added to Todos: "+ str);
		 Assert.assertEquals(str, "2");
	  }
	  
	  @AfterMethod
	  public void teardown()
	  {
		 driver.quit();
		  
	  }
	

}
