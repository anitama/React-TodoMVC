package TodoMVC_TestCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import TodoMVC_Prerequisite.TestBase;

public class TestCase2_VerifyTextBoxEnabled extends TestBase
{
	@BeforeMethod
	  public void setup() throws IOException
	  {
		  TestBase.initialization();  
	  }
	  
	  @Test
	  public void Verify_isTextBoxEnabled()
	  {
		 Boolean textboxstatus= driver.findElement(By.xpath("//input[@class='new-todo']")).isEnabled();
		 Assert.assertTrue(textboxstatus);  
	  }
	  
	  @AfterMethod
	  public void teardown()
	  {
		 driver.quit();
		  
	  }
	
	

}
