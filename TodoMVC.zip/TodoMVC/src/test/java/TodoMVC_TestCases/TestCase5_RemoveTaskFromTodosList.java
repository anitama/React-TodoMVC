package TodoMVC_TestCases;

import java.io.IOException;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import TodoMVC_Prerequisite.TestBase;

public class TestCase5_RemoveTaskFromTodosList extends TestBase
{

	@BeforeMethod
	  public void setup() throws IOException
	  {
		  TestBase.initialization();  
	  }
	
	  @Test
	  public void Verify_clearcompleted()
	  {
		 WebElement inputbox= driver.findElement(By.xpath("//input[@class='new-todo']"));
		 inputbox.sendKeys("Task1");
		 inputbox.sendKeys(Keys.ENTER);
		 inputbox.sendKeys("Task1");
		 inputbox.sendKeys(Keys.ENTER);
		 inputbox.sendKeys("Task1");
		 inputbox.sendKeys(Keys.ENTER);
		 String Totaltask_before= driver.findElement(By.xpath("//span[@class='todo-count']/strong")).getText();
		 System.out.println("Total Todos Task Before Clear completed :"+Totaltask_before);
		 List<WebElement>wblis= driver.findElements(By.xpath("//div[@class='view']//input[@type='checkbox']"));
	     wblis.get(0).click(); 
		 driver.findElement(By.xpath("//button[@class='clear-completed']")).click();
		 String Totaltask_after= driver.findElement(By.xpath("//span[@class='todo-count']/strong")).getText();
		 System.out.println("Total Todos Task After Clear Completed : "+Totaltask_after);
		 
		 if (! Totaltask_after.equals(Totaltask_before))
		 {
			System.out.println("Task removed from Todos list"); 
			 
		 }
		 else
		 {
			 System.out.println("Task not removed from Todos list"); 
			 
		 }
	  }
	  
	  @AfterMethod
	  public void teardown()
	  {
		  driver.quit();
		  
	  }
}
