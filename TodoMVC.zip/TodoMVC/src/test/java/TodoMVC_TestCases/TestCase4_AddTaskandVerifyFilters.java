package TodoMVC_TestCases;

import java.io.IOException;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import TodoMVC_Prerequisite.TestBase;

public class TestCase4_AddTaskandVerifyFilters extends TestBase
{
	@BeforeMethod
	  public void setup() throws IOException
	  {
		  TestBase.initialization();  
	  }
	
	  @Test
	  public void Verify_filters()
	  {
		 WebElement inputbox= driver.findElement(By.xpath("//input[@class='new-todo']"));
		 inputbox.sendKeys("Task1");
		 inputbox.sendKeys(Keys.ENTER);
		 String filter1= driver.findElement(By.xpath("//ul[@class='filters']/li[1]")).getText();
		 Assert.assertEquals(filter1, "All");
		 String filter2= driver.findElement(By.xpath("//ul[@class='filters']/li[2]")).getText();
		 Assert.assertEquals(filter2, "Active");
		 String filter3= driver.findElement(By.xpath("//ul[@class='filters']/li[3]")).getText();
		 Assert.assertEquals(filter3, "Completed");
		 
	  }
	  
	  @AfterMethod
	  public void teardown()
	  {
		 driver.quit();
		  
	  }
	


}
